# %%
if __name__ == '__main__':
    import os
    # Check if current environment is google colab.
    # If so, execute following specific lines
    if 'google-cloud-sdk' in os.environ['PATH']:
        print('Google colab environment')
        from google.colab import drive
        drive.mount('/content/drive')
    # !pip install cvui roipoly sounddevice soundfile pytictoc statannot ffmpeg-python videofig seqnmf joypy phenograph
        processing_root = '../../closedloop_processing/1ROI/'
    else:
        processing_root = '/media/pankaj/WDEX4/google_drive/guptapg@tcd.ie/closedloop_processing/1ROI/'
    import sys
    sys.path.append("..")
    import numpy as np
    import cv2
    from skimage.transform import resize
    from scipy import ndimage, misc
    from scipy.ndimage import gaussian_filter
    from scipy import stats,signal,fft
    from scipy import io as sio
    import matplotlib.pyplot as plt
    import matplotlib.cm as cm
    from matplotlib.dates import DateFormatter
    import matplotlib.patches as patches
    from matplotlib.backends.backend_pdf import PdfPages
    import matplotlib
    matplotlib.use('tkagg')
    import pandas as pd
    import phenograph
    import io
    import imageio
    from IPython.core.debugger import set_trace
    from pathlib import Path
    from numpy import sin, linspace, pi
    from pylab import plot, show, title, xlabel, ylabel, subplot
    from datetime import datetime
    import glob
    from sklearn.manifold import TSNE
#%%
    K = 15
    L = 14
    coords_all = []
    H_trial = []
    H_rest = []
# %%
    coords_all = pd.read_csv('2d_poses.csv')
    coords_all = coords_all.values
    communities, graph, Q = phenograph.cluster(coords_all)
    n_clus = np.unique(communities).shape[0]
# tsne_model = TSNE(n_components=2, perplexity=30.0, early_exaggeration=12.0,
#                   learning_rate=20.0, n_iter=1000, n_iter_without_progress=300,
#                   min_grad_norm=1e-07, metric='euclidean', init='random',
#                   verbose=0, random_state=None, method='barnes_hut',
#                   angle=0.5)
# tsne_model = TSNE(n_components=2,perplexity=30,random_state=0)
    tsne_model = TSNE(n_components=2, random_state=2,perplexity=50,angle=0.1,init='pca')
    Y = tsne_model.fit_transform(coords_all)
# cmap = matplotlib.colors.ListedColormap ( np.random.rand ( np.unique(communities).shape[0],3))
    cmap = plt.cm.colors.ListedColormap(plt.cm.jet(np.linspace(0,1,n_clus)))
    plt.figure()
    plt.scatter(Y[:,0], Y[:,1],
                    c=communities,
                    cmap=cmap,
                    alpha=1.0)
    plt.colorbar(ticks=np.unique(communities), label='Cluster#')
    plt.xlabel('TSNE1'); plt.ylabel('TSNE2')
    plt.title('Body coordinate clusters: total frames ' + str(len(communities)))
    plt.savefig('synthetic_2d_cluster.png', format='png')
    plt.show(block=False)
    plt.close()
# res = pd.DataFrame(coords_all).groupby(communities).apply(lambda x: x.values)
# coords_clus_mean = [b.mean(axis=0) for b in res]
# coords_clus_mean = [b.reshape(128*128,15) for b in coords_clus_mean]
# coords_clus_mean = [b.reshape(128,128,15) for b in coords_clus_mean]
# coords_clus_mean = np.array(coords_clus_mean)
# coords_clus_mean = np.moveaxis(coords_clus_mean, 0, -1)
# coords_clus_mean = np.swapaxes(coords_clus_mean, 2, 3)
# coords_clus_mean = motif_clus_mean.reshape(128,128*n_clus,15,order='F')
# images = []
# for i in np.arange(coords_clus_mean.shape[2]):
#     fig = plt.figure(figsize=(20.0, 5.0));
#     plt.imshow(gaussian_filter(coords_clus_mean[:,:,i],3),cmap=cm.jet, vmin=0, vmax=0.6);
#     plt.colorbar()
#     plt.subplots_adjust(0,0,1,1,0,0);
#     images.append(get_img_from_fig(fig))
#     plt.close()
# imageio.mimwrite('synthetic_2d_cluster_mean.gif', images)
# %%
    coords_all = pd.read_csv('3d_poses.csv')
    coords_all = coords_all.values
    communities, graph, Q = phenograph.cluster(coords_all)
    n_clus = np.unique(communities).shape[0]
# tsne_model = TSNE(n_components=2, perplexity=30.0, early_exaggeration=12.0,
#                   learning_rate=20.0, n_iter=1000, n_iter_without_progress=300,
#                   min_grad_norm=1e-07, metric='euclidean', init='random',
#                   verbose=0, random_state=None, method='barnes_hut',
#                   angle=0.5)
# tsne_model = TSNE(n_components=2,perplexity=30,random_state=0)
    tsne_model = TSNE(n_components=2, random_state=2,perplexity=50,angle=0.1,init='pca')
    Y = tsne_model.fit_transform(coords_all)
# cmap = matplotlib.colors.ListedColormap ( np.random.rand ( np.unique(communities).shape[0],3))
    cmap = plt.cm.colors.ListedColormap(plt.cm.jet(np.linspace(0,1,n_clus)))
    plt.figure()
    plt.scatter(Y[:,0], Y[:,1],
                    c=communities,
                    cmap=cmap,
                    alpha=1.0)
    plt.colorbar(ticks=np.unique(communities), label='Cluster#')
    plt.xlabel('TSNE1'); plt.ylabel('TSNE2')
    plt.title('Body coordinate clusters: total motifs ' + str(len(communities)))
    plt.savefig('synthetic_3d_cluster.png', format='png')
    plt.show(block=False)
    plt.close()
# res = pd.DataFrame(coords_all).groupby(communities).apply(lambda x: x.values)
# motif_clus_mean = [b.mean(axis=0) for b in res]
# motif_clus_mean = [b.reshape(128*128,15) for b in motif_clus_mean]
# motif_clus_mean = [b.reshape(128,128,15) for b in motif_clus_mean]
# motif_clus_mean = np.array(motif_clus_mean)
# motif_clus_mean = np.moveaxis(motif_clus_mean, 0, -1)
# motif_clus_mean = np.swapaxes(motif_clus_mean, 2, 3)
# motif_clus_mean = motif_clus_mean.reshape(128,128*n_clus,15,order='F')
# images = []
# for i in np.arange(motif_clus_mean.shape[2]):
#     fig = plt.figure(figsize=(20.0, 5.0));
#     plt.imshow(gaussian_filter(motif_clus_mean[:,:,i],3),cmap=cm.jet, vmin=0, vmax=0.6);
#     plt.colorbar()
#     plt.subplots_adjust(0,0,1,1,0,0);
#     images.append(get_img_from_fig(fig))
#     plt.close()
# imageio.mimwrite('synthetic_3d_cluster_mean.gif', images)
# only replace with a directory of yours
# finally .npy files saved in your directory with names train.npy, #test.npy, train_labels.npy, test_labels.npy
import glob
import numpy as np
import cv2
train = []
files = glob.glob ("D:/Github_downloads/3D_model_compare_kid/kid_data/real/gt1new/*.png") # your image path
for myFile in files:
    image = cv2.imread (myFile)
    train.append (image)
train = np.array(train,dtype='float32') #as mnist
#as mnist# convert (number of images x height x width x number of channels) to (number of images x (height * width *3)) 
# for example (120 * 40 * 40 * 3)-> (120 * 4800)
train = np.reshape(train,[train.shape[0],train.shape[3],train.shape[1],train.shape[2]])
# save numpy array as .npy formats
np.save('gt1new',train)